<template>
  <SpaceTimeSelect />
</template>

<script setup>
import SpaceTimeSelect from "@/components/SpaceTimeSelect/index.vue";
</script>

<style>

</style>
