<script setup>
</script>

<template>
  Data explore
</template>
