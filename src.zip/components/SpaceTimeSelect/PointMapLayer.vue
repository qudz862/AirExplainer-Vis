<template>
  <div class='outer-container'>
    <ul class="nav nav-tabs">
      <li class="nav-item"><a class="nav-link active"  data-bs-toggle="tab" href="#home">Province & city</a></li>
      <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#profile">Natural regions</a></li>
      <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#contact">Climate regions</a></li>
      <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#contact">Vegetation regions</a></li>
    </ul>
    <div class="tab-content">
      <div class="tab-pane fade show active">
          <div class="input-group mb-3">
          <select class="form-select" >
            <option selected>Choose province</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          <select class="form-select">
            <option selected>Choose city</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
      </div>
      <div class="tab-pane fade">
          <div class="input-group mb-3">
          <select class="form-select">
            <option selected>Choose natural region</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          <select class="form-select">
            <option selected>Choose natural sub-region</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          <select class="form-select">
            <option selected>Choose natural zone</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
      </div>
      <div class="tab-pane fade">
        <div class="input-group mb-3">
          <select class="form-select">
            <option selected>Choose climate region</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          <select class="form-select">
            <option selected>Choose climate zone</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
      </div>
      <div class="tab-pane fade">
        <div class="input-group mb-3">
          <select class="form-select">
            <option selected>Choose vegetation region</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
          <select class="form-select">
            <option selected>Choose vegetation zone</option>
            <option value="1">One</option>
            <option value="2">Two</option>
            <option value="3">Three</option>
          </select>
        </div>
      </div>
    </div>
    <div class="st-sel-block">
      <div class="map-container" id="map-container"></div>
      <!-- <div>选中了{{ sel_point_num }}个点</div> -->
      <div class="time-var-block">
        <div class="time-config-content">
          <div>Time range</div>
          <div class="form-group">
            <div class="form-row">
                <div>Start: </div> 
                <input type="date" name="startTime" class="form-control" 
                max="2018-12-31" min="2013-01-01" 
                v-model="startTime" @change="onStartTimeChange()">
            </div>
            <div class="form-row">
                <div>End: </div> 
                <input type="date" name="endTime" class="form-control" 
                max="2018-12-31" min="2013-01-01" 
                v-model="endTime" @change="onEndTimeChange()">
            </div>
          </div>
      </div>
      <div class="var-select">
        <div>Input Features:</div>
        <div>Air quality: </div>
        <div class='var-container'>
          <div v-for="item in inputFeaturePoint.air" class="form-check">
            <input class="form-check-input" type="checkbox" :value="item" v-model="curInputFeatures.air" @change="onInputFeatureChange">
            <label class="form-check-label">{{ item }}</label>
          </div>
        </div>
        <div>Climate: </div>
        <div class='var-container'>
          <div v-for="item in inputFeaturePoint.climate" class="form-check">
            <input class="form-check-input" type="checkbox" :value="item" v-model="curInputFeatures.climate" @change="onInputFeatureChange">
            <label class="form-check-label">{{ item }}</label>
          </div>
        </div>
        <div>Space: </div>
        <div class='var-container'>
          <div v-for="item in inputFeaturePoint.space" class="form-check">
            <input class="form-check-input" type="checkbox" :value="item" v-model="curInputFeatures.space" @change="onInputFeatureChange">
            <label class="form-check-label">{{ item }}</label>
          </div>
        </div>
        <div>Output Features:</div>
        <div class='var-container'>
          <div v-for="item in outputFeaturePoint" class="form-check">
            <input class="form-check-input" type="checkbox" :value="item" v-model="curOutputFeatures" @change="onOutputFeatureChange">
            <label class="form-check-label">{{ item }}</label>
          </div>
        </div>
      </div>
    </div>
      
    <div class='data-save-block'>
      <div>Data identifier</div>
      <input type="text" class="form-control" :placeholder="sel_data_name" v-model="sel_data_name">
      <div>Data description (optionally)</div>
      <textarea class="form-control" rows="6" v-model="sel_data_description" placeholder=""></textarea>
      <button id="save-data-btn" type="button" class="btn btn-primary" @click="saveSelData">Save selected data</button>
    </div>
    <!-- <div>选中了{{ sel_day_num+1 }}天</div> -->
    </div>
    
    <!-- <div>Divide train & test data</div>
    <div>
      <span>{{ train_data_rate + '%' }}</span>
      <input type="range" class="form-range" min="0" max="100" step="5" v-model="train_data_rate">
      <span>{{ (100-train_data_rate) + '%' }}</span>
    </div> -->

    <!-- <div>
      <button id="train-btn" type="button" class="btn" @click="trainModel">Build & Train Model</button>
    </div> -->
    
  </div>
</template>

<script setup>
import { ref, reactive, computed, watch, onMounted } from "vue";
import mapboxgl from "mapbox-gl";
import turf from 'turf'
import MapboxDraw from "@mapbox/mapbox-gl-draw";
import { useStore } from 'vuex'
import getData from '@/services'
import { inputFeaturePoint, outputFeaturePoint } from '@/data'

const store = useStore(),
    state = store.state
getData(store, 'point_loc')
const stateObj = computed(() => state).value

let curInputFeatures = ref({
  air: [...stateObj.selInputFeaturePoint.air],
  climate: [...stateObj.selInputFeaturePoint.climate],
  space: [...stateObj.selInputFeaturePoint.space]
})
let curOutputFeatures = ref([...stateObj.selOutputFeaturePoint])

const onInputFeatureChange = () => {
  store.commit('setData', {
    field: 'change_input_feature_point',
    data: curInputFeatures.value
  })
}

const onOutputFeatureChange = () => {
  store.commit('setData', {
    field: 'change_output_feature_point',
    data: curOutputFeatures.value
  })
}

// watch(() => stateObj.selInputFeaturePoint, (newVal, oldVal) => {
//   console.log(stateObj.selInputFeaturePoint);
// }, {deep: true})

// watch(() => stateObj.selOutputFeaturePoint, (newVal, oldVal) => {
//   console.log(stateObj.selOutputFeaturePoint);
// })

const trainModel = () => {
  getData(store, 'train_model', 'point', JSON.stringify(stateObj.selectedPoints), JSON.stringify(stateObj.pointTimeRange), JSON.stringify(stateObj.selInputFeaturePoint), JSON.stringify(stateObj.selOutputFeaturePoint))
}

let map
let draw
let pointList = []

mapboxgl.accessToken = 'pk.eyJ1IjoiZGV6aGFudmlzIiwiYSI6ImNraThnYWoxcDA1aXkycnMzMGxhcDcxeGgifQ.pbnOr8oKR894OJ3seHIayg'

const startTime = ref("2013-01-01")
const endTime = ref("2018-12-31")


let sel_point_num = ref(0)
let sel_region_flag = false
let sel_region_type = ref('Arbitrary')

let sel_region = reactive({
  sel_province: '',
  sel_city: '',
  sel_natural_region: '',
  sel_natural_sub_region: '',
  sel_natural_zone: '',
  sel_climate_region: '',
  sel_climate_zone: '',
  sel_vegetation_region: '',
  sel_vegetation_zone: ''
})

let sel_day_num = computed(() => {
  let start_date = new Date(startTime.value)
  let end_date = new Date(endTime.value)
  return (end_date - start_date) / (1000 * 60 * 60 * 24)
})
let sel_data_name = computed(() => {
  let space_type = ''
  if (sel_region_type.value == 'Arbitrary') {
    space_type = `Arbitrary-${sel_point_num.value}P`
  }

  let reg = new RegExp("-","g");
  let name = `${space_type}_${startTime.value.replace(reg,"")}-${endTime.value.replace(reg,"")}_I`
  for (let i in stateObj.selInputFeaturePoint) {
    for (let j = 0; j < stateObj.selInputFeaturePoint[i].length; ++j)
    name = name + '-' + stateObj.selInputFeaturePoint[i][j]
  }
  name = name + '_O'
  for (let i in stateObj.selOutputFeaturePoint) {
    name = name + '-' + stateObj.selOutputFeaturePoint[i]
  }
  return name
})

let sel_data_infor = computed(() => {
  let space_type = ''
  if (sel_region_type.value == 'Arbitrary') {
    space_type = `Arbitrary-${sel_point_num.value}P`
  }

  let infor = {
    'data_type': 'point',
    'data_name': sel_data_name._value,
    'data_description': sel_data_description.value,
    'selectedPoints': stateObj.selectedPoints,
    'selSpaceType': space_type,
    'pointTimeRange': stateObj.pointTimeRange,
    'selInputFeaturePoint': stateObj.selInputFeaturePoint,
    'selOutputFeaturePoint': stateObj.selOutputFeaturePoint
  }

  return infor
})

// const train_data_rate = ref(70)
const sel_data_description = ref('')

const saveSelData = () => {
  getData(store, 'save_sel_data', JSON.stringify(sel_data_infor.value))
}

watch(()=>stateObj.saveSelDataState, (newVal, oldVal) => {
  console.log(stateObj.saveSelDataState);
})

const onStartTimeChange = () => {
    store.commit('setData', {
        field: 'select_point_time',
        data: {
            "start": startTime.value,
            "end": endTime.value
        }
    })
}

const onEndTimeChange = () => {
    store.commit('setData', {
        field: 'select_point_time',
        data: {
            "start": startTime.value,
            "end": endTime.value
        }
    })
}

function getLL(d) {
    return new mapboxgl.LngLat(+d.lng, +d.lat)
}

function project(d) {
    return map.project(getLL(d));
}

const initDraw = () => {
    draw = new MapboxDraw()
    // let navigation = new mapboxgl.NavigationControl()
    // let scale_ctl =  new mapboxgl.ScaleControl({
    //     maxWidth: 80,
    //     unit: 'imperial'
    // })
    // let full_screen_ctl = new mapboxgl.FullscreenControl()
    // map.addControl(navigation, 'bottom-right')
    // map.addControl(full_screen_ctl, 'bottom-right')
    // map.addControl(scale_ctl, 'bottom-right')

    map.addControl(draw, 'bottom-right')

    map.on('draw.create', updateArea)
    map.on('draw.update', updateArea)
    map.on('draw.delete', updateArea)
}

const updateArea = (e) => {
    //   map.setFilter("points-selected", ["==", "group", ""]);
      if (e.type === 'draw.delete') {
        map.setFilter("points-selected", ["in", "loc_id", ""]);
        // map.setFilter("points-selected", ["==", "group", ""]);
        pointList = []
        store.commit('setData', {
          field: 'select_point',
          data: pointList
        })
        return
      }

      var data = draw.getAll()
      if (data.features.length > 0) {
        var userPolygon = e.features[0];
        var polygonBoundingBox = turf.bbox(userPolygon);
        var southWest = [polygonBoundingBox[0], polygonBoundingBox[1]];
        var northEast = [polygonBoundingBox[2], polygonBoundingBox[3]];
        var northEastPointPixel = map.project(northEast);
        var southWestPointPixel = map.project(southWest);
        var features = map.queryRenderedFeatures([southWestPointPixel, northEastPointPixel], { layers: ['points'] });
        var filter = features.reduce(function(memo, feature) {
          if (! (undefined === turf.intersect(feature, userPolygon))) {
            // only add the property, if the feature intersects with the polygon drawn by the user
            // memo.push(feature.properties.title);
            memo.push(feature.properties.loc_id);
          }
          return memo;
        }, []);
        pointList = filter
        store.commit('setData', {
          field: 'select_point',
          data: pointList
        })
        map.setFilter("points-selected", ["in", "loc_id", ...filter]);
      } else {
        // answer.innerHTML = '';
      }
    }

watch(()=>stateObj.selectedPoints, (newVal, oldVal) => {
  sel_point_num.value = stateObj.selectedPoints.length
})

onMounted(() => {
    map = new mapboxgl.Map({
        container: 'map-container',
        style: 'mapbox://styles/dezhanvis/ckmcv57z60gjd17rq1jvowlcr',
        center: [105.605285,37.6],
        zoom: 2.4,
        zoomControl: true
      })
    map._logoControl && map.removeControl(map._logoControl);  // 去除mapbox标志
    initDraw()
})

watch (() => stateObj.mapPointsUpdate, (oldVlaue, newValue) => {
    // map.on('load', () => {
        map.addSource("points", {
          "type": "geojson",
          "data": {
            "type": "FeatureCollection",
            "features": stateObj.pointLocs
          }
        })

        map.addLayer({
          "id": "points",
          "type": "circle",   /* symbol类型layer，一般用来绘制点*/
          "source": "points",
          paint: {
            'circle-radius': 2,
            'circle-color': '#fec006'
          }
        });

        map.addLayer({
          "id": "points-selected",
          "type": "circle",
          "source": "points",
          "paint": {
            'circle-radius': 2,
            'circle-color': '#eb6877'
          },
          "filter": ["in", "loc_id", '']  /* 过滤器，名字为空的数据才显示，也就是默认不使用该layer  */
        });
    // })
})

</script>

<style scoped>
@import url("https://api.tiles.mapbox.com/mapbox-gl-js/v0.44.2/mapbox-gl.css");
@import url("https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-draw/v1.3.0/mapbox-gl-draw.css");

.outer-container {
  width: 1080px;
}

.map-container {
  /* margin: 0 auto; */
  /* position: absolute; */
  /* left: 300; */
  width: 400px;
  height: 360px;
  margin-right: 20px;
}

.time-config-content {
  /* width: 400px; */
}

.time-var-block {
  margin-right: 20px;
}

.time-var-block .form-row {
  width: 290px;
  /* margin: 0 auto; */
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 15px;
  margin-bottom: 5px;
}

.time-var-block .form-control {
  width: 240px;
  font-size: 15px;
  padding: 0 4px;
  height: 28px;
}

#get-data-btn {
  width: 270px;
  height: 32px;
  padding: 2px 0px;
  margin-top: -3px;
  border: solid 1px #9a9a9a;
  border-radius: 16px;
  color: #333;
}

.data-save-block {
  width: 320px;
}

#save-data-btn {
  margin-top: 10px;
}

.var-container {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
}

#train-btn {
  width: 270px;
  height: 32px;
  padding: 2px 0px;
  margin-top: 14px;
  border: solid 1px #9a9a9a;
  border-radius: 16px;
  color: #333;
}

.nav {
  width: 660px;
}

.tab-content {
  width: 635px;
}

.st-sel-block {
  display: flex;
}

.time-var-block {
  width: 400px;
}
</style>