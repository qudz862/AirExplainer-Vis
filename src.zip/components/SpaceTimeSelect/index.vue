<template>
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link" :class="gridTabActive" @click="changeTabType('grid')">Grid</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" :class="cityTabActive" @click="changeTabType('city')">City</a>
        </li>
    </ul>
    <!-- <CityMapLayer />
    <PointMapLayer /> -->
    <KeepAlive>
        <component :is="cur_tab"></component>
    </KeepAlive>

    <div>Existed data</div>
    <table class="table table-hover">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Identifier</th>
            <th scope="col">Space</th>
            <th scope="col">Time range</th>
            <th scope="col">Input features</th>
            <th scope="col">Output features</th>
            <th scope="col">Description</th>
            <th scope="col">Added time</th>
            <th scope="col">State</th>
            <th scope="col">operation</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for = "(item,index) in stateObj.existedDataNameList" :value="item">
            <td scope="row" >{{ index+1 }}</td>
            <td class='identifier' :title="item.data_name">{{ item.data_name }}</td>
            <td>{{ item.selSpaceType }}</td>
            <td>{{ item.pointTimeRange.start }}~{{ item.pointTimeRange.end }}</td>
            <td>{{ item.selInputFeaturePoint.air }} {{ item.selInputFeaturePoint.climate }} {{ item.selInputFeaturePoint.space }}</td>
            <td>{{ item.selOutputFeaturePoint }}</td>
            <td>{{ item.data_description }}</td>
            <td>{{ item.addedTime }}</td>
            <td>{{ item.state }}</td>
          </tr>
        </tbody>
    </table>
    

    <!-- <div class="existed-data-card" v-for="item in stateObj.existedDataNameList" :value="item">
        <input class="form-control" type="text" :value="item" :title="item">
        <div>Added time: xxxxx</div>
        <div>Description: xxxxxxxxxxx</div>
    </div> -->

    <!-- <select class="form-select" size="3" v-model="sel_data_name">
        <option v-for="item in stateObj.existedDataNameList" :value="item">{{ item }}</option>
    </select> -->
</template>

<script setup>
import PointMapLayer from './PointMapLayer.vue'
import CityMapLayer from './CityMapLayer.vue'
import { ref, onMounted, computed, watch, markRaw } from "vue"
import { useStore } from 'vuex'
import getData from '@/services'

const store = useStore(),
    state = store.state
const stateObj = computed(() => state).value

// console.log(stateObj.existedDataNameList);

const cur_tab = ref(markRaw(PointMapLayer))
const cityTabActive = ref('')
const gridTabActive = ref('active')

const tabs = {CityMapLayer, PointMapLayer}
let sel_data_name = ref('')

const changeTabType = (newType) => {
    if (newType == 'city') {
        cityTabActive.value = 'active'
        gridTabActive.value = ''
        cur_tab.value = markRaw(CityMapLayer)
    } else if (newType == 'grid') {
        cityTabActive.value = ''
        gridTabActive.value = 'active'
        cur_tab.value = markRaw(PointMapLayer) 
    }
}

onMounted(() => {
    getData(store, 'existed_data_names')
})

// watch (() => stateObj.existedDataNameList, (oldVal, newVal) => {
//     // existed_data_names.value = [...stateObj.existedDataNameList]
//     console.log(stateObj.existedDataNameList[0]);
// })


watch (() => stateObj.model_train_result, (oldVal, newVal) => {
    console.log(stateObj.model_train_result);
})

</script>

<style scoped>
.existed-data-card {
    width: 400px;
    border: solid 1px #999;
    margin: 5px 5px;
}

.identifier {
    max-width: 120px;
    overflow: hidden; /*超出隐藏*/
    text-overflow: ellipsis;/*文字隐藏后添加省略号*/
    white-space: nowrap;/*强制不换行*/
}

.nav-link {
    cursor: pointer !important;
}

</style>